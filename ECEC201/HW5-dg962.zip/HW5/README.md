ECE-C201 Homework 5
===================

Provide your solution to Problem 1 in the file named `Q1.c`, Problem 2 in `Q2.c`, etc.

To help get you started, there are instructions at the top of each C
file that briefly describe how to compile and run the code for each
question.

Name your zip file: `HW5-abc123.zip`

Use your Drexel username instead of `abc123`! :)

The structure of your zip file should be as follows:

HW5-abc123.zip
 |- Q1.c
 |- Q2.c
 +- Q3.c

Do not name your files differently.


(Please see Lab 1 for details regarding how to submit an assignment)
