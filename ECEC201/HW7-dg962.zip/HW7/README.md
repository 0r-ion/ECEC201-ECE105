ECE-C201 Homework 7
===================

Provide your solution in the file named `main.c`.

Name your zip file: `HW7-abc123.zip`

Zip your solution so that your files are not in a folder.

For example:

HW7-abc123.zip
 |- main.c
 |- test.dat
 +- README.md

Use your Drexel username instead of `abc123`! :) 
