/* Homework 2: Question 4
   Compile with: gcc -std=c89 -o Q4 Q4.c
   Then run your compiled program with: ./Q4
*/

#include <stdio.h>
int main()
{ 
    int ret, num;
    int count = 0;
    printf("give me a number:");
    ret = scanf("%d", &num);
    if (ret != 1){
        printf("scanf error\n");
        return 1;
    }

    
    do{
        num /= 10;
        count++; 
    }while(num != 0);
    printf("the number had %d digits\n",count);
    return 0;
}