/* Homework 2: Question 1
   Compile with: gcc -std=c89 -o Q1 Q1.c
   Then run your compiled program with: ./Q1
*/

#include <stdio.h>
int main() {
    int ret, num;
    printf("give me a number:");
    ret = scanf("%d", &num);
    if (ret != 1){
        printf("scanf error\n");
        return 1;
    }
    if(0 <= num && num <= 9){
        printf("the number %d has 1 digit\n", num);
        return 0;
    }
    else if(10 <= num && num <= 99){
        printf("the number %d has 2 digits\n", num);
        return 0;
    }
    else if(100 <= num && num <= 999){
        printf("the number %d has 3 digits\n", num);
        return 0;
    }
    else if(1000 <= num && num <= 9999){
        printf("the number %d has 4 digits\n", num);
        return 0;
    }
    else{
        printf("ERROR num was 5 or more digits or was negative\n");
        return 0;
    }

  return 0;
}
