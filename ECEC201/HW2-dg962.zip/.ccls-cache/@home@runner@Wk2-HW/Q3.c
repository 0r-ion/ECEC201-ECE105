/* Homework 2: Question 3
   Compile with: gcc -std=c89 -o Q3 Q3.c
   Then run your compiled program with: ./Q3
*/
#include <stdio.h>
#define REALDAY i-start_day+1

int main()
{
    int ret, total_days, start_day, i;
    printf("enter the number of days in the month:");
    ret = scanf("%d",&total_days);
    if(!ret){
        printf("error\n");
        return 1;
    }
    printf("Enter starting day of the week (1=Sun, 7=Sat):");
    ret = scanf("%d",&start_day);
    if(!ret){
        printf("error\n");
        return 1;
    }

    for(i = 1; i <= start_day + total_days -1; i++){
        if(i < start_day){
            printf("   ");
        }
        else if(i%7 == 0){
            printf(" %2d\n", REALDAY);
        }else{
            printf(" %2d", REALDAY);
        }
    }
    printf("\n");
    return 0;
}