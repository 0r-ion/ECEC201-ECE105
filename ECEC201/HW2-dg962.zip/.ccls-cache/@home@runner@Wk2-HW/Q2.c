/* Homework 2: Question 2
   Compile with: gcc -std=c89 -o Q2 Q2.c
   Then run your compiled program with: ./Q2
   
Income	Amount of tax	 
*/
#include <stdio.h>

int main()
{
    int ret;
    float income, tax = 0;
    printf("input your income:");
    ret = scanf("%f", &income);
    /*
    Not over $750	1% of income	 
    $750--$2,250	$7.50   plus 2% of amount over $750
    $2,250--$3,750	$37.50	plus 3% of amount over $2,250
    $3,750--$5,250	$82.50	plus 4% of amount over $3,750
    $5,250--$7,000	$142.50	plus 5% of amount over $5,250
    Over $7,000	$230.00	plus 6% of amount over $7,000
    */
    printf("income = %f\n",income);
    if(income <= 750){
        tax = income * .01;
    }
    if(750 <= income && income <= 2250){
        tax = 7.50 + (income - 750) * .02;
    }
    if(2250 <= income && income <= 3750){
        tax = 37.50 + (income - 2250) * .03;
    }
    if(3750 <= income && income <= 5250){
        tax = 82.50 + (income - 3750) * .04;
    }
    if(5250 <= income && income <= 7000){
        tax = 142.50 + (income - 5250) * .05;
    }
    if(7000 <= income){
        tax = 230.00 + (income - 7000) * .06; 
    }
    printf("Tax due: %.2f\n", tax);
    return 0;
}