ECE-C201 Homework 6
===================

Provide your solution to Problem 1 in the file named `Q1.c`, Problem 2 in `Q2.c`, etc.

To begin editing a file, click its name in the **Files** panel on the left.

Compile and run each C file manually.  To help get you started, there are
instructions at the top of each C file that briefly describe how to compile
and run the code for each question.

If you are unable to see the terminal window (where you type the commands to compile
and run your program), you may need to click the **Console** tab at the top of the
window next to this one.

Do not use the **Run** button at the top of the screen.  It will not work properly in
this situation.

When you are ready to submit your assignment, select **Download as zip** from the
**Files** menu on the left and upload your zip file to BBLearn like you did for Lab 1.

Name your zip file: `HW6-abc123.zip`

Use your Drexel username instead of `abc123`! :) 


(Please see Lab 1 for details regarding how to submit an assignment)