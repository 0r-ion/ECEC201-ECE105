/* Homework 1: Question 2
   Compile with: gcc -o Q2 Q2.c
   Then run your compiled program with: ./Q2
*/

#include <stdio.h>

int main() {
  int imp;
  int result;
  scanf("%d", &imp);
  result = result + 3 * (imp * imp * imp * imp * imp);
  result = result + 2 * (imp * imp * imp * imp);
  result = result - 5 * (imp * imp * imp);
  result = result - (imp * imp);
  result = result + 7 * imp;
  result = result - 6;

  printf("result is:%d\n", result);
  return 0;
}