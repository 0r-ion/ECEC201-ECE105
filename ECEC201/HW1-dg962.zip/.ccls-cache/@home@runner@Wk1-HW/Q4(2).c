/* Homework 1: Question 4
   Compile with: gcc -o Q4 Q4.c
   Then run your compiled program with: ./Q4
*/

#include <stdio.h>

int main()
{


}