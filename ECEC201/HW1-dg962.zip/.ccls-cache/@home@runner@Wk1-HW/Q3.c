/* Homework 1: Question 3
   Compile with: gcc -o Q3 Q3.c
   Then run your compiled program with: ./Q3
*/

#include <stdio.h>

int main(void) {
    int num1, denom1, num3, denom3, result_num, result_denom, ret;

    printf("Enter first fraction: ");
    ret = scanf("%d / %d", &num1, &denom1);
    // printf("scancode:%d|%d / %d\n", ret, num1, denom1);
    if (ret != 2 || denom1 == 0){
        printf("please enter a valid fraction");
        return 1;
    }

    printf("Enter the second fraction: ");
    ret = scanf("%d / %d", &num3, &denom3);
    // printf("scancode:%d|%d / %d\n", ret, num3, denom3);
    if (ret != 2 || denom3 == 0){
        printf("please enter a valid fraction");
        return 1;
    }

    result_num = num1 * denom3 + num3 * denom1;
    result_denom = denom1 * denom3;

    printf("The sum is %d/%d\n", result_num, result_denom);

    return 0;
}
