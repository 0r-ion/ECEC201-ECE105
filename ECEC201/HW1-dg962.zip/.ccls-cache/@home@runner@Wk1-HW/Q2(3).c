/* Homework 1: Question 2
   Compile with: gcc -o Q2 Q2.c
   Then run your compiled program with: ./Q2
*/

#include <stdio.h>

int main()
{


}