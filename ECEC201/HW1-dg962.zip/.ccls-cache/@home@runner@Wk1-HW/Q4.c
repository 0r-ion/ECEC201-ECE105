/* Homework 1: Question 4
   Compile with: gcc -o Q4 Q4.c
   Then run your compiled program with: ./Q4
*/

#include <stdio.h>

int main() {
    int ret, first, second, last;
    printf("Enter phone number [(xxx)xxx-xxxx]:");
    scanf("(%d)%d-%d", &first, &second, &last);
    printf("You entered %d.%d.%d\n", first, second, last); 
    return 0;
}