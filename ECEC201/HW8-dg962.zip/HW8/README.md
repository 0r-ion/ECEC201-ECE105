ECE-C201 Homework 8
===================

Provide your solution in the file named `main.c`.

When you are ready to submit your assignment, select **Download as zip** from the
**Files** menu on the left and upload your zip file to BBLearn like you did for Lab 1.

Name your zip file: `HW8-abc123.zip`

Use your Drexel username instead of `abc123`! :) 


(Please see Lab 1 for details regarding how to submit an assignment)